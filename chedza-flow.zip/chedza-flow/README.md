# Chedza × CMS — Fixed Property Claims Flow

A single self-contained web page (`index.html`) showing the Chedza / Contractor
Management Support claims flow. All fonts and images are embedded, so it needs
no build step and no internet connection to render — it works as-is on GitHub
Pages, any web host, or by opening the file locally.

## What's in here

- `index.html` — the whole design, self-contained.
- `.github/workflows/deploy.yml` — auto-publishes the page to GitHub Pages on every push to `main`.
- `.nojekyll` — tells GitHub Pages to serve the files as-is (no Jekyll processing).

## Deploy it (one time setup)

1. Create a new repository on GitHub (it must be **Public** on the free plan).
2. Push these files to the `main` branch:

   ```bash
   git init
   git add .
   git commit -m "Add Chedza CMS claims flow"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```

3. In the repository, go to **Settings → Pages**.
4. Under **Build and deployment → Source**, choose **GitHub Actions**.

That's it. The included workflow runs automatically, and your page goes live at:

```
https://<your-username>.github.io/<repo-name>/
```

The first build takes a minute or two — watch progress under the **Actions** tab.

## Updating the page

Edit `index.html`, then:

```bash
git add index.html
git commit -m "Update flow"
git push
```

Every push to `main` redeploys automatically.

## Alternative (no Actions)

If you prefer the simplest route: under **Settings → Pages → Source** pick
**Deploy from a branch**, select `main` and `/ (root)`, and Save. GitHub will
serve `index.html` directly. (In that case the workflow file is optional.)
